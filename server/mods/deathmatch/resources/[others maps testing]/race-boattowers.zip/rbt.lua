
local function addWater(x, y, width, height)
	local z = 100
	local hw = width / 2
	local hh = height / 2
	--outputChatBox("Water @ (" .. x .. ", " .. y .. ", " .. z .. ")", root, 0, 255, 255)
	return createWater(x - hw, y - hh, z, x + hw, y - hh, z, x - hw, y + hh, z, x + hw, y + hh, z)
end

local function doRepair(p, sameDim)
	if getElementType(p) == "player" and not isPedDead(p) then
		local veh = getPedOccupiedVehicle(p)
		if veh ~= nil then
			fixVehicle(veh)
			playSoundFrontEnd(p, 46)
		end
	end
end

local function killOoB(p, sameDim)
	if getElementType(p) == "player" and not isPedDead(p) then
		-- 55 gives skull, 54 is falling
		killPed(p, nil, 55)
	end
end

local platDist = 90
local sizeLg = 150
local sizeMd = 98
local sizeSm = 18
local sizeEx = platDist * 4 + sizeSm

local x2 = 525
local y2 = -2475
local x1 = x2 - platDist * 2
local y1 = y2 - platDist * 2

--outputChatBox("x1=" .. (x1 + 5 - sizeLg / 2) .. ", y1=" .. (y1 + 5 - sizeLg / 2) .. ", x3=" .. (x2 + platDist * 2 + sizeLg / 2 - 5) .. ", y3=" .. (y2 + platDist * 2 + sizeLg / 2 - 5), root, 0, 255, 0)

local gameArea = createColCuboid(x1 - platDist * 2, y1 - platDist * 2, 95, platDist * 8, platDist * 8, 30)

-- main platforms
for y = 0, 4, 2 do
	local cy = y1 + y * platDist
	for x = 0, 4, 2 do
		local cx = x1 + x * platDist
		local sz = (x + y) % 4 == 2 and sizeMd or sizeLg
		addWater(cx, cy, sz, sz)
	end
end

-- being lazy and overlapping water
for i = 0, 4, 2 do
	addWater(x2, y1 + i * platDist, sizeEx, sizeSm)
	addWater(x1 + i * platDist, y2, sizeSm, sizeEx)
end

-- repairs
for y = -1, 1, 2 do
	local oy = y2 + platDist * y
	for x = -1, 1, 2 do
		local ox = x2 + platDist * x
		local circle = createColCircle(ox, oy, 7.5)
		addEventHandler("onColShapeHit", circle, doRepair)
	end
end

addEventHandler("onColShapeLeave", gameArea, killOoB)
