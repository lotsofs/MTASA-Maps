
local platDist = 90
local x2 = 525
local y2 = -2475
local icons = {}
local cam = getCamera()

local function setModel(id, txd, modelPath)
	engineImportTXD(txd, id)
	local dff = engineLoadDFF(modelPath)
	engineReplaceModel(dff, id)
	engineSetModelLODDistance(id, 800)
end

local function poorMansBillboard()
	local rx, ry, rz = getElementRotation(cam)
	for i = 1, 4, 1 do
		setElementRotation(icons[i], rx, ry, rz)
	end
end

for y = 0, 2, 2 do
	local oy = y2 + platDist * (y - 1)
	for x = 0, 1, 1 do
		local idx = x + y + 1
		local rot = idx % 3 == 1 and 135 or 45
		local ox = x2 + platDist * (x * 2 - 1)
		icons[idx] = createObject(3096, ox, oy, 107.5, 0, 0, rot)
	end
end

addEventHandler ( "onClientResourceStart", resourceRoot,
	function ()
		local txd = engineLoadTXD("models/rbt.txd")
		setModel(9900, txd, "models/twr_mid.dff")
		setModel(9037, txd, "models/twr_end.dff")
		setModel(10758, txd, "models/twr_sml.dff")
		setModel(10763, txd, "models/bridge.dff")
	end
)

setTimer(poorMansBillboard, 33, 0)